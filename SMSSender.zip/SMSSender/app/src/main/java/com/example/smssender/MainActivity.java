package com.example.smssender;
import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.Activity;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.PowerManager;
import android.support.annotation.NonNull;
import android.telephony.SmsManager;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    Button upload,send;
    ListView listView;
    ImageButton sendSMSBtn;
    EditText smsMessageET;
    String name,number;

    int count = 0, i = 0;
    PendingIntent sentPI;
    String m_chosen;

    public static int limit, pause, deleteNum;

    ProgressDialog progressBar;
    ArrayList<String> nmbers = new ArrayList<>();

    SharedPreferences sharedpreferences;
    String filePath = "";
    PowerManager.WakeLock wl;
    private static final int STORAGE_PERMISSION_CODE = 123;
    public static final int REQUEST_LOCATION_CODE = 1000;



    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        upload=findViewById(R.id.upload);
        send=findViewById(R.id.sms);
        smsMessageET=findViewById(R.id.editText1);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            getWindow().setStatusBarColor(getResources().getColor(R.color.colorPrimaryDark));
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
        requestStoragePermission();

        limit = 900;
        pause = 3;
        deleteNum = 1;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.SEND_SMS},
                        REQUEST_LOCATION_CODE);
            }
        }
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                    STORAGE_PERMISSION_CODE);
        }
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (smsMessageET.getText().toString().isEmpty())
                    Toast.makeText(getBaseContext(), "Message can not be empty!", Toast.LENGTH_SHORT).show();
                else if (filePath.isEmpty()) {
                    Toast.makeText(getBaseContext(), "Please choose a file!", Toast.LENGTH_SHORT).show();
                } else

                    sendSMS();

            }
        });
        upload.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("InvalidWakeLockTag")
            @Override
            public void onClick(View v) {
                if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.SEND_SMS)
                        != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.SEND_SMS},
                            REQUEST_LOCATION_CODE);
                }
                SimpleFileDialog FileOpenDialog = new SimpleFileDialog(MainActivity.this, "FileOpen",
                        new SimpleFileDialog.SimpleFileDialogListener() {
                            @Override
                            public void onChosenDir(String chosenDir) {
                                m_chosen = chosenDir;
                                filePath = m_chosen;
                                //                               Toast.makeText(MainActivity.this, "Chosen File: " + m_chosen, Toast.LENGTH_SHORT).show();
                                BufferedReader br;
                                String ids[];
                                try {
                                    File inputFile = new File(m_chosen);
                                    InputStream inputStream = new FileInputStream(inputFile);
                                    br = new BufferedReader(new InputStreamReader(inputStream));
                                    String line;
                                    while ((line = br.readLine()) != null) {

                                        ids=line.split(",");
                                        // name=ids[0].toString();
                                        try{
                                            nmbers.add(ids[1].toString());
                                        }catch (Exception e)
                                        {
                                            Toast.makeText(MainActivity.this, "Please Select excel file with (.cvs) format", Toast.LENGTH_SHORT).show();
                                        }
                                        //nmbers.add(new Gettersetter(name,number));

                                    }

//                                    String[] namesArr = nmbers.toArray(new String[nmbers.size()]);
                                    ArrayAdapter adapter=new ArrayAdapter(MainActivity.this,android.R.layout.simple_list_item_1,nmbers);
                                    //                myAdapter = new MyAdapter(nmbers, MainActivity.this);
                                    listView.setAdapter(adapter);
                                } catch (IOException io) {
                                    io.printStackTrace();
                                }

                            }
                        });
                FileOpenDialog.Default_File_Name = "";
                FileOpenDialog.chooseFile_or_Dir();

                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "My Tag");
                wl.acquire(10*60*1000L /*10 minutes*/);
                progressBar = new ProgressDialog(v.getContext());
                progressBar.setCancelable(false);
                progressBar.setMessage("SMS Sending...");
                progressBar.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                progressBar.setProgress(0);

            }//onclik
        });
    }

    protected void sendSMS() {
        String SENT = "SENT_SMS_ACTION";
        sentPI = PendingIntent.getBroadcast(this, 0, new Intent(SENT), 0);
        registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context arg0, Intent arg1) {
                count++;
                i++;
                switch (getResultCode()) {
                    case Activity.RESULT_OK:
                        if (deleteNum == 1) {
//                            String nm = nmbers.get(i - 1);
//                            nmbers.remove(nm);
//                            i--;
//                            PrintWriter writer;
//                            try {
//                                writer = new PrintWriter(filePath);
//                                for (int t = 0; t < nmbers.size(); t++) {
//                                    writer.println(nmbers.get(t));
//                                }
//                                writer.close();
//                            } catch (FileNotFoundException e) {
//                                e.printStackTrace();
//                            }
                        }
                        break;
                    case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                        Toast.makeText(getBaseContext(), "Generic failure",
                                Toast.LENGTH_SHORT).show();
                        break;
                    case SmsManager.RESULT_ERROR_NO_SERVICE:
                        Toast.makeText(getBaseContext(), "No service",
                                Toast.LENGTH_SHORT).show();
                        break;
                    case SmsManager.RESULT_ERROR_NULL_PDU:
                        Toast.makeText(getBaseContext(), "Null PDU",
                                Toast.LENGTH_SHORT).show();
                        break;
                    case SmsManager.RESULT_ERROR_RADIO_OFF:
                        Toast.makeText(getBaseContext(), "Radio off",
                                Toast.LENGTH_SHORT).show();
                        break;
                }
                if (i < nmbers.size()) {
                    progressBar.setProgress(count);
                    if (count % limit == 0 && count > 0) {
                        try {
                            Thread.sleep((pause * 1000));
                        } catch (InterruptedException e) {
                            //e.printStackTrace();
                        }
                    }
                    sendIt();
                } else {
                    progressBar.dismiss();
                    smsMessageET.setText("");
                    Toast.makeText(getBaseContext(), "All SMS Sent", Toast.LENGTH_SHORT).show();
                    wl.release();
                }
            }
        }, new IntentFilter(SENT));
        progressBar.setMax(nmbers.size());
        progressBar.show();
        sendIt();
    }

    void sendIt() {
        try {

            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(nmbers.get(i), null, smsMessageET.getText().toString(), sentPI, null);
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "failed to " + nmbers.get(i), Toast.LENGTH_LONG).show();
        }
    }
    private void requestStoragePermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)
            return;

        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_EXTERNAL_STORAGE)) {
            //If the user has denied the permission previously your code will come to this block
            //Here you can explain why you need this permission
            //Explain here why you need this permission
        }
        //And finally ask for the permission
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, STORAGE_PERMISSION_CODE);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, STORAGE_PERMISSION_CODE);

        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED)
            return;

        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
            //If the user has denied the permission previously your code will come to this block
            //Here you can explain why you need this permission
            //Explain here why you need this permission
        }
        //And finally ask for the permission
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, REQUEST_LOCATION_CODE);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, REQUEST_LOCATION_CODE);

        }


    }


}//final
